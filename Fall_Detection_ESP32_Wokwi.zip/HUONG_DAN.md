# Phát hiện té ngã với ESP32 và MPU6050

## 1. Chạy mạch Wokwi và dashboard

1. Giải nén ZIP. Mở https://wokwi.com/projects/new/esp32 và thay nội dung hai tab `sketch.ino` và `diagram.json` bằng nội dung các tệp tương ứng.
2. Trong tab **Library Manager** của Wokwi, bấm **+** và thêm **PubSubClient**. Tệp `libraries.txt` liệt kê thư viện cần dùng.
3. Bấm **Start Simulation**. Serial Monitor hiển thị `ax`, `ay`, `az`, độ lớn gia tốc và góc nghiêng. Khi để cảm biến mặc định, kết quả gần `ax=0, ay=0, az=1 g, góc=0°`.
4. Mở `dashboard.html` bằng trình duyệt có Internet. Wokwi dùng **Wokwi-GUEST**. ESP32 kết nối broker EMQX qua TCP cổng 1883, còn trình duyệt kết nối `wss://broker.emqx.io:8084/mqtt`.
5. Để kiểm tra manual, chọn **Thủ công**, chờ ESP32 xác nhận, rồi bấm lần lượt hai nút **Đèn LED** và **Còi**. Bấm lại để tắt. Chuyển về **Tự động** để thử thuật toán. Manual chỉ ghi đè ngõ ra, thuật toán vẫn tính và dashboard vẫn hiển thị cờ té ngã.
6. Để thử tự động, bấm vào MPU6050 đang chạy và đổi thông số gia tốc. Từ `(0,0,1)`, giữ Y = 0 và Z = 1, tăng X lên khoảng 3 g để tạo va chạm. Trong 1,5 giây sau khi tạo va chạm, đưa X về khoảng 1 g và Z về 0 g. Giữ tư thế này ít nhất 350 ms. Đèn và còi sẽ bật 8 giây nếu các mẫu đạt ngưỡng. Nếu thao tác quá chậm, đưa về `(0,0,1)`, giữ ngắn để thiết lập tư thế tham chiếu rồi thử lại. Chỉ nghiêng từ từ hoặc chỉ tạo xung gia tốc rồi trở về tư thế đứng sẽ không kích hoạt cảnh báo.

## 2. Nối dây

| Linh kiện | Chân | ESP32 |
|---|---|---|
| MPU6050 | VCC | 3V3 |
| MPU6050 | GND | GND |
| MPU6050 | SDA | GPIO21 |
| MPU6050 | SCL | GPIO22 |
| LED đỏ | A | GPIO25 qua điện trở 220 Ω |
| LED đỏ | C | GND |
| Còi piezo | 2 (+) | GPIO26 |
| Còi piezo | 1 (−) | GND |

Nếu lắp còi công suất ngoài mô phỏng, chọn mạch kích theo điện áp và dòng định mức của còi. Firmware dùng ESP32 hai lõi và phát âm 2,2 kHz cho piezo.

## 3. FreeRTOS và MQTT

| Task | Core | Hoạt động |
|---|---:|---|
| Task đọc data | 1 | Đọc MPU6050 mỗi 20 ms, gửi mỗi mẫu vào `dataQueue` và `dataAlert`. In Serial mỗi 250 ms. |
| Task cảnh báo | 1 | Rút các mẫu trong `dataAlert`, chạy thuật toán và cập nhật LED/còi. Nhận lệnh manual qua `commandQueue`, gửi trạng thái thực về `stateQueue`. |
| Task truyền data | 0 | Kết nối Wi-Fi và MQTT, tự thử lại. Đọc mẫu mới nhất từ `dataQueue` và trạng thái từ `stateQueue` để publish khoảng 4 lần/giây. Nhận lệnh MQTT rồi chuyển cho task cảnh báo. |

`dataQueue` chứa một mẫu mới nhất để web bắt kịp số đo sau khi mạng trở lại. `dataAlert` chứa tối đa 24 mẫu theo thứ tự lấy mẫu để task cảnh báo nhận được xung gia tốc ngắn.

| Topic | Nội dung |
|---|---|
| `utc/fall/8c317a82dd624959/telemetry` | JSON có `ms, ax, ay, az, g, tilt, fall, manual, led, buzzer` |
| `utc/fall/8c317a82dd624959/cmd` | `auto`, `manual`, `led:on`, `led:off`, `buzzer:on`, `buzzer:off` |

Broker công cộng dùng cho dữ liệu mô phỏng. Nếu chạy nhiều bản mô phỏng độc lập, thay chuỗi topic gốc trong cả `sketch.ino` và `dashboard.html` cho từng bản.

## 4. Cách tính và điều kiện cảnh báo

MPU6050 lấy mẫu gia tốc ba trục ở dải ±8 g. Gia tốc tổng hợp bằng `sqrt(ax² + ay² + az²)`. Góc nghiêng bằng `atan2(sqrt(ax² + ay²), az)`, đổi sang độ. Đây là góc giữa vectơ gia tốc đo được và trục +Z của cảm biến. Ước lượng theo trọng lực có ý nghĩa nhất khi cơ thể tương đối ổn định, nên chương trình xác nhận tư thế sau va chạm.

- Gắn cảm biến sao cho trục +Z hướng lên khi người đứng. Mẫu trước va chạm có độ lớn trong khoảng 0,8–1,2 g được dùng làm tham chiếu.
- Mở cửa sổ xác nhận 1,5 giây khi độ lớn gia tốc đạt ít nhất 2,2 g.
- Xác nhận nếu góc đạt ít nhất 60° và lệch ít nhất 45° so với tham chiếu, đồng thời độ lớn trở lại khoảng 0,8–1,2 g. Các điều kiện phải giữ liên tục ít nhất 350 ms.
- Bật cảnh báo 8 giây ở chế độ tự động. Các ngưỡng là giá trị khởi đầu cho mô phỏng và cần hiệu chỉnh khi thay đổi vị trí gắn cảm biến hoặc thử với dữ liệu thực tế.

Tài liệu: https://docs.wokwi.com/parts/wokwi-mpu6050 · https://docs.wokwi.com/parts/wokwi-buzzer · https://www.emqx.com/en/mqtt/public-mqtt5-broker
